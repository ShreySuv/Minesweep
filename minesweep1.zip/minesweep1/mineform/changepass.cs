﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace minesweep1.mineform
{
    public partial class changepass : Form
    {
        datamanager.datamanager dm = new datamanager.datamanager();
        public changepass()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string old = txtold.Text;
            //string npassword;
            string qry = "select * from tbl_logpage where log_username='" + Program.maindes + "' and log_Activeflag=1";
            DataSet ds = dm.GetDataSet(qry);
            if (ds.Tables[0].Rows.Count > 0)
            {
                string npassword = ds.Tables[0].Rows[0]["log_pass"].ToString();
                if (npassword == old)
                {
                    if (txtcon.Text == "")
                    {
                        MessageBox.Show("Confirm Password");
                    }
                    else if (txtnew.Text == txtcon.Text)
                    {
                        if (txtnew.Text.Length < 6)
                        {
                            MessageBox.Show("Please enter password(6 character)");
                            //txtnew.Focus();
                           
                        }
                        else
                        {
                            string qry1 = "update tbl_logpage set log_pass='" + txtnew.Text + "' where log_MasterId='" + Program.usermid + "'";
                            string res = dm.ExecuteQuery(qry1);
                            if (res == "executed successfully")
                            {
                                MessageBox.Show("Password Updated Successfully");
                                clearall();
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password does not match");
                        clearall();
                    }
                }
                else
                {
                    MessageBox.Show("Enter correct Old Password");
                    clearall();
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //string qry = "select * from tbl_logpage where log_MasterId='" + Program.usermid + "' and log_Activeflag=1";
            //DataSet ds = dm.GetDataSet(qry);
            //string des = ds.Tables[0].Rows[0]["log_designation"].ToString();
            if (Program.maindes == "admin")
            {
                Aadminpage FRM = new Aadminpage();
                FRM.Show();
                this.Hide();
            }
            else
            {
                MDIHome FRM = new MDIHome();
                FRM.Show();
                this.Hide();
            }
        }

        private void changepass_Load(object sender, EventArgs e)
        {
            txtold.Focus();
        }
        public void clearall()
        {

            txtold.Text = "";
            txtnew.Text = "";
            txtcon.Text = "";
            txtold.Focus();

        }

        private void txtnew_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
