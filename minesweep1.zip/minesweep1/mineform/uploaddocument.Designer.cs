﻿namespace minesweep1.mineform
{
    partial class uploaddocument
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.folderpath = new System.Windows.Forms.Button();
            this.grpsel = new System.Windows.Forms.GroupBox();
            this.lblFileCnt = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtpath = new System.Windows.Forms.TextBox();
            this.grpsel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // folderpath
            // 
            this.folderpath.BackColor = System.Drawing.Color.Transparent;
            this.folderpath.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.folderpath.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.folderpath.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.folderpath.ForeColor = System.Drawing.Color.Transparent;
            this.folderpath.Location = new System.Drawing.Point(559, 213);
            this.folderpath.Name = "folderpath";
            this.folderpath.Size = new System.Drawing.Size(135, 35);
            this.folderpath.TabIndex = 0;
            this.folderpath.Text = "browse";
            this.folderpath.UseVisualStyleBackColor = false;
            this.folderpath.Click += new System.EventHandler(this.folderpath_Click);
            // 
            // grpsel
            // 
            this.grpsel.BackColor = System.Drawing.Color.Transparent;
            this.grpsel.Controls.Add(this.lblFileCnt);
            this.grpsel.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpsel.Location = new System.Drawing.Point(176, 275);
            this.grpsel.Name = "grpsel";
            this.grpsel.Size = new System.Drawing.Size(259, 122);
            this.grpsel.TabIndex = 2;
            this.grpsel.TabStop = false;
            this.grpsel.Enter += new System.EventHandler(this.grpsel_Enter);
            // 
            // lblFileCnt
            // 
            this.lblFileCnt.AutoSize = true;
            this.lblFileCnt.Location = new System.Drawing.Point(26, 91);
            this.lblFileCnt.Name = "lblFileCnt";
            this.lblFileCnt.Size = new System.Drawing.Size(107, 25);
            this.lblFileCnt.TabIndex = 3;
            this.lblFileCnt.Text = "FileCount  :";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.AliceBlue;
            this.listBox1.Font = new System.Drawing.Font("Papyrus", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.Color.Navy;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 18;
            this.listBox1.Location = new System.Drawing.Point(489, 287);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(547, 310);
            this.listBox1.TabIndex = 4;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1355, 48);
            this.panel1.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(39, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 36);
            this.label1.TabIndex = 5;
            this.label1.Text = "Minesweep";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(-1, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(480, 63);
            this.label2.TabIndex = 15;
            this.label2.Text = "Upload Resumes\r\n";
            // 
            // txtpath
            // 
            this.txtpath.Location = new System.Drawing.Point(176, 221);
            this.txtpath.Name = "txtpath";
            this.txtpath.Size = new System.Drawing.Size(339, 20);
            this.txtpath.TabIndex = 16;
            // 
            // uploaddocument
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::minesweep1.Properties.Resources.images__2_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.txtpath);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.grpsel);
            this.Controls.Add(this.folderpath);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "uploaddocument";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "uploaddocument";
            this.grpsel.ResumeLayout(false);
            this.grpsel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button folderpath;
        private System.Windows.Forms.GroupBox grpsel;
        private System.Windows.Forms.Label lblFileCnt;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtpath;
    }
}