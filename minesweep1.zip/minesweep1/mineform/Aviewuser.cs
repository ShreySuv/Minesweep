﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace minesweep1.mineform
{
    public partial class Aviewuser : Form
    {
        datamanager.datamanager dm = new datamanager.datamanager();
       // BindGrid(dataGridView1, "select log_username,log_contact,log_Sex,log_designation,log_email from tbl_logpage where log_Activeflag=1");


        // string qrry = "select log_username,log_contact,log_Sex,log_designation,log_email from tbl_logpage where log_username= ' " + txtname.Text + " ' and log_Activeflag=1 ";
        public Aviewuser()
        {
            InitializeComponent();
            //BindGrid(dataGridView1, "select log_username,log_contact,log_Sex,log_designation,log_email from tbl_logpage where log_Activeflag=1");
        }
        //BindGrid(dataGridView1, "select log_username,log_contact,log_Sex,log_designation,log_email from tbl_logpage where log_Activeflag=1");
        public bool isvalid()
        {
            if (txtname.Text == "")
            {
                MessageBox.Show("Please enter username");
                txtname.Focus();
                return false;
            }
            return true;
        }

       
        public void BindGrid(DataGridView dv, string qrry)
        {
            DataSet ds = dm.GetDataSet(qrry);
            if (ds.Tables[0].Rows.Count > 0)
            {

                dv.DataSource = ds.Tables[0];
               

            }
            else
            {
                dv.DataSource = ds.Tables[0];
                
            }

        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnok_Click(object sender, EventArgs e)
        {
            if (isvalid())
            {
                string username = txtname.Text;
                string qry = "select log_username,log_contact,log_Sex,log_designation,log_email from tbl_logpage where log_username='" + username + "' and log_Activeflag=1";
                DataSet ds = dm.GetDataSet(qry);
              //  BindGrid(dataGridView1, qry);
              //  string qry1 = "select log_username from tbl_logpage where log_Activeflag=1 ";
                //DataSet ds1 = dm.GetDataSet(qry1);
                if (ds.Tables[0].Rows.Count > 0) // if (res != "")
                {
                    BindGrid(dataGridView1, qry);
                }
                else
                {
                    MessageBox.Show("Username does not exist!");
                }
               
                
                /*if (ds.Tables[0].Rows.Count > 0)
                {

                    if (username != "")
                    {
                        MessageBox.Show(num);   
                    }
                    else
                    {
                        uploaddocument FRM = new uploaddocument();
                        FRM.Show();
                        this.Hide();
                    }
                }*/
            }

                else
                {
                    MessageBox.Show("Username does not exist!");
                }
            
        }

        private void Aviewuser_Load(object sender, EventArgs e)
        {
            BindGrid(dataGridView1, "select log_username,log_contact,log_Sex,log_designation,log_email from tbl_logpage where log_username!='admin' and log_Activeflag=1");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //BindGrid(dataGridView1, "select log_username,log_contact,log_Sex,log_designation,log_email from tbl_logpage where log_Activeflag=1");
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Aadminpage FRM = new Aadminpage();
            FRM.Show();
            this.Hide();
        }
    }
}
