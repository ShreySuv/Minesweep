﻿namespace minesweep1.mineform
{
    partial class newform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(newform));
            this.lblrul1 = new System.Windows.Forms.Label();
            this.cbrul1 = new System.Windows.Forms.ComboBox();
            this.cbrul2 = new System.Windows.Forms.ComboBox();
            this.cbrul3 = new System.Windows.Forms.ComboBox();
            this.cbrul4 = new System.Windows.Forms.ComboBox();
            this.cbrul5 = new System.Windows.Forms.ComboBox();
            this.cbrul6 = new System.Windows.Forms.ComboBox();
            this.cbrul7 = new System.Windows.Forms.ComboBox();
            this.cbrul8 = new System.Windows.Forms.ComboBox();
            this.lble1 = new System.Windows.Forms.Label();
            this.btnsetRule = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblrul1
            // 
            this.lblrul1.AutoSize = true;
            this.lblrul1.BackColor = System.Drawing.Color.Transparent;
            this.lblrul1.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrul1.Location = new System.Drawing.Point(17, 11);
            this.lblrul1.Name = "lblrul1";
            this.lblrul1.Size = new System.Drawing.Size(78, 25);
            this.lblrul1.TabIndex = 0;
            this.lblrul1.Text = "Rule 1   :";
            // 
            // cbrul1
            // 
            this.cbrul1.FormattingEnabled = true;
            this.cbrul1.Location = new System.Drawing.Point(101, 14);
            this.cbrul1.Name = "cbrul1";
            this.cbrul1.Size = new System.Drawing.Size(206, 21);
            this.cbrul1.TabIndex = 4;
            this.cbrul1.SelectedIndexChanged += new System.EventHandler(this.cbrul1_SelectedIndexChanged);
            // 
            // cbrul2
            // 
            this.cbrul2.FormattingEnabled = true;
            this.cbrul2.Location = new System.Drawing.Point(101, 15);
            this.cbrul2.Name = "cbrul2";
            this.cbrul2.Size = new System.Drawing.Size(206, 21);
            this.cbrul2.TabIndex = 5;
            this.cbrul2.SelectedIndexChanged += new System.EventHandler(this.cbrul2_SelectedIndexChanged);
            // 
            // cbrul3
            // 
            this.cbrul3.FormattingEnabled = true;
            this.cbrul3.Location = new System.Drawing.Point(101, 16);
            this.cbrul3.Name = "cbrul3";
            this.cbrul3.Size = new System.Drawing.Size(206, 21);
            this.cbrul3.TabIndex = 6;
            this.cbrul3.SelectedIndexChanged += new System.EventHandler(this.cbrul3_SelectedIndexChanged);
            // 
            // cbrul4
            // 
            this.cbrul4.FormattingEnabled = true;
            this.cbrul4.Location = new System.Drawing.Point(101, 13);
            this.cbrul4.Name = "cbrul4";
            this.cbrul4.Size = new System.Drawing.Size(206, 21);
            this.cbrul4.TabIndex = 7;
            this.cbrul4.SelectedIndexChanged += new System.EventHandler(this.cbrul4_SelectedIndexChanged);
            // 
            // cbrul5
            // 
            this.cbrul5.FormattingEnabled = true;
            this.cbrul5.Location = new System.Drawing.Point(518, 14);
            this.cbrul5.Name = "cbrul5";
            this.cbrul5.Size = new System.Drawing.Size(198, 21);
            this.cbrul5.TabIndex = 8;
            // 
            // cbrul6
            // 
            this.cbrul6.FormattingEnabled = true;
            this.cbrul6.Location = new System.Drawing.Point(518, 14);
            this.cbrul6.Name = "cbrul6";
            this.cbrul6.Size = new System.Drawing.Size(198, 21);
            this.cbrul6.TabIndex = 9;
            // 
            // cbrul7
            // 
            this.cbrul7.FormattingEnabled = true;
            this.cbrul7.Location = new System.Drawing.Point(518, 15);
            this.cbrul7.Name = "cbrul7";
            this.cbrul7.Size = new System.Drawing.Size(198, 21);
            this.cbrul7.TabIndex = 10;
            // 
            // cbrul8
            // 
            this.cbrul8.FormattingEnabled = true;
            this.cbrul8.Location = new System.Drawing.Point(518, 13);
            this.cbrul8.Name = "cbrul8";
            this.cbrul8.Size = new System.Drawing.Size(198, 21);
            this.cbrul8.TabIndex = 11;
            this.cbrul8.SelectedIndexChanged += new System.EventHandler(this.comboBox8_SelectedIndexChanged);
            // 
            // lble1
            // 
            this.lble1.AutoSize = true;
            this.lble1.BackColor = System.Drawing.Color.Transparent;
            this.lble1.Font = new System.Drawing.Font("Papyrus", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lble1.Location = new System.Drawing.Point(397, 0);
            this.lble1.Name = "lble1";
            this.lble1.Size = new System.Drawing.Size(34, 42);
            this.lble1.TabIndex = 12;
            this.lble1.Text = "=";
            // 
            // btnsetRule
            // 
            this.btnsetRule.BackColor = System.Drawing.Color.Transparent;
            this.btnsetRule.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btnsetRule.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsetRule.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsetRule.ForeColor = System.Drawing.Color.Transparent;
            this.btnsetRule.Location = new System.Drawing.Point(460, 494);
            this.btnsetRule.Name = "btnsetRule";
            this.btnsetRule.Size = new System.Drawing.Size(128, 58);
            this.btnsetRule.TabIndex = 16;
            this.btnsetRule.Text = "SET";
            this.btnsetRule.UseVisualStyleBackColor = false;
            this.btnsetRule.Click += new System.EventHandler(this.btnsetRule_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1355, 48);
            this.panel1.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(39, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 36);
            this.label1.TabIndex = 5;
            this.label1.Text = "Minesweep";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(-1, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(341, 126);
            this.label2.TabIndex = 18;
            this.label2.Text = "Apply Rules\r\n\r\n";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Papyrus", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Navy;
            this.label7.Location = new System.Drawing.Point(36, 123);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(711, 51);
            this.label7.TabIndex = 19;
            this.label7.Text = "Choose well. Your choice is brief, and yet endless.\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 25);
            this.label3.TabIndex = 20;
            this.label3.Text = "Rule 4  :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 25);
            this.label4.TabIndex = 21;
            this.label4.Text = "Rule 3  :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 25);
            this.label5.TabIndex = 22;
            this.label5.Text = "Rule 2  :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Papyrus", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(397, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 42);
            this.label6.TabIndex = 23;
            this.label6.Text = "=";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Papyrus", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(397, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 42);
            this.label8.TabIndex = 24;
            this.label8.Text = "=";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Papyrus", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(397, 1);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 42);
            this.label9.TabIndex = 25;
            this.label9.Text = "=";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.lblrul1);
            this.panel2.Controls.Add(this.cbrul1);
            this.panel2.Controls.Add(this.lble1);
            this.panel2.Controls.Add(this.cbrul5);
            this.panel2.Location = new System.Drawing.Point(133, 209);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(789, 38);
            this.panel2.TabIndex = 26;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.cbrul2);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.cbrul6);
            this.panel3.Location = new System.Drawing.Point(133, 272);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(789, 39);
            this.panel3.TabIndex = 27;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.cbrul3);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.cbrul7);
            this.panel4.Location = new System.Drawing.Point(133, 339);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(789, 40);
            this.panel4.TabIndex = 28;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.cbrul4);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.cbrul8);
            this.panel5.Location = new System.Drawing.Point(133, 403);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(789, 43);
            this.panel5.TabIndex = 29;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(962, 214);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 31);
            this.button1.TabIndex = 30;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Transparent;
            this.button2.Location = new System.Drawing.Point(962, 275);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 33);
            this.button2.TabIndex = 31;
            this.button2.Text = "+";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Transparent;
            this.button3.Location = new System.Drawing.Point(962, 343);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 32);
            this.button3.TabIndex = 32;
            this.button3.Text = "+";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // newform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1244, 614);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnsetRule);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "newform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "papan";
            this.Load += new System.EventHandler(this.newform_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblrul1;
        private System.Windows.Forms.ComboBox cbrul1;
        private System.Windows.Forms.ComboBox cbrul2;
        private System.Windows.Forms.ComboBox cbrul3;
        private System.Windows.Forms.ComboBox cbrul4;
        private System.Windows.Forms.ComboBox cbrul5;
        private System.Windows.Forms.ComboBox cbrul6;
        private System.Windows.Forms.ComboBox cbrul7;
        private System.Windows.Forms.ComboBox cbrul8;
        private System.Windows.Forms.Label lble1;
        private System.Windows.Forms.Button btnsetRule;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}