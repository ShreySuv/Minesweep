﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace minesweep1.mineform
{
    public partial class synonyms : Form
    {
        datamanager.datamanager dm = new datamanager.datamanager();
        string qrry = "select row_number() over(order by Synonym_MasterId)as slno,Synonym_MasterId,Standardterm,Synonyms from tbl_Synonyms where Synonym_ActiveFlag=1";
        public synonyms()
        {
            InitializeComponent();
        }
       
        private void txtst_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int synmid = int.Parse(dataGridView1.CurrentRow.Cells["mid"].Value.ToString());
            Program.synmid = synmid;
            if (e.ColumnIndex == 0)
            {
                btnsave.Visible = false;
                btnup.Visible = true;
                txtst.Text = dataGridView1.CurrentRow.Cells["Column2"].Value.ToString();
                txtsyn.Text = dataGridView1.CurrentRow.Cells["Column3"].Value.ToString();

            }
            if (e.ColumnIndex == 1)
            {
                DialogResult dr = MessageBox.Show("Are u sure?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    string qry10 = "update tbl_Synonyms set Synonym_ActiveFlag=0 where Synonym_MasterId = '" + Program.synmid + "'";
                    string res10 = dm.ExecuteQuery(qry10);
                    if (res10 != "")
                    {
                        MessageBox.Show("success");
                        BindGrid(dataGridView1, qrry);
                    }
                    else
                    {
                        MessageBox.Show("nope");
                    }
                }
            }
        }
        public bool isvalid()
        {
            if (txtst.Text == "")
            {
                MessageBox.Show("Please enter standard term");
                txtst.Focus();
                return false;
            }
            if (txtsyn.Text == "")
            {
                MessageBox.Show("Please enter synonym");
                txtsyn.Focus();
                return false;
            }
            return true;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (isvalid())
            {
                string qry1 = "select * from tbl_Synonyms where Synonym_ActiveFlag=1 and Synonyms='" + txtsyn.Text + "'";
                    if (!dm.CheckIsRecordExist(qry1))
                    {


                string stdterm = txtst.Text;
                string synm = txtsyn.Text;
                string qry = "insert into tbl_Synonyms (Standardterm , Synonyms) values ('" + stdterm + "','" + synm + "')";
                string res = dm.ExecuteQuery(qry);
                if (res != "")
                {
                    MessageBox.Show("SUCCESS");
                    clearall();
                    BindGrid(dataGridView1, qrry);
                    
                }
                else
                {
                    MessageBox.Show("UNSUCCESSFULL");
                }

                    }

                    else
                    {
                        MessageBox.Show("Record Already Exists");
                    }

            }

        }
        public void BindGrid(DataGridView dv, string qrry)
        {
            DataSet ds = dm.GetDataSet(qrry);
            if (ds.Tables[0].Rows.Count > 0)
            {

                dv.DataSource = ds.Tables[0];
                lblcount.Text = ds.Tables[0].Rows.Count.ToString();

            }
            else
            {
                dv.DataSource = ds.Tables[0];
                lblcount.Text = "0";
            }
            
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void synonyms_Load(object sender, EventArgs e)
        {
            btnsave.Visible = true;
            btnup.Visible = false;
            BindGrid(dataGridView1, qrry); 
        }

        private void txtsyn_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnup_Click(object sender, EventArgs e)
        {
            if (isvalid())
            {
                string stdterm = txtst.Text;
                string synm = txtsyn.Text;
                
                string qry1 = "update tbl_Synonyms set Standardterm='" + stdterm + "',Synonyms='" + synm + "' where Synonym_ActiveFlag=1 and Synonym_MasterId='" + Program.synmid + "'";
                string res = dm.ExecuteQuery(qry1);
                if (res != "")
                {
                    

                    BindGrid(dataGridView1, qrry);
                    btnsave.Visible = true;
                    btnup.Visible = false;
                    clearall();
                }
                else
                {
                    MessageBox.Show("UNSUCCESSFULL");
                }
            }
        }

        private void btnrest_Click(object sender, EventArgs e)
        {
            clearall();
        }
        public void clearall()
        {

            txtst.Text = "";
            txtsyn.Text = "";
            btnsave.Visible = true;
            btnup.Visible = false;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void syn_Click(object sender, EventArgs e)
        {

        }
    }
}
