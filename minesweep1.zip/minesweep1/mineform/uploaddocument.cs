﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace minesweep1.mineform
{
    public partial class uploaddocument : Form
    {
        string[] strfilearray;
        public uploaddocument()
        {
            InitializeComponent();
        }

        private void grpsel_Enter(object sender, EventArgs e)
        {

        }

        private void folderpath_Click(object sender, EventArgs e)
        {
            //if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            //{
            //    this.label1.Text = folderBrowserDialog1.SelectedPath;


            //}
            string strfilepath = "";
            
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                strfilepath = fbd.SelectedPath.ToString();

                strfilearray = new string[System.IO.Directory.GetFiles(strfilepath).Length];
                strfilearray = System.IO.Directory.GetFiles(strfilepath);


            }
            txtpath.Text = strfilepath;//to select source folder
            string path = txtpath.Text;

            if (path.Trim() != "")
            {
                string[] strAllfiles = Directory.GetFiles(path);
                funcAddfiles(strAllfiles);
                System.Windows.Forms.Application.DoEvents();

            }


            

            int i = strfilearray.Length - 1;

            int filecount = 0;
            while (i >= 0)
            {
                // if (!(strfilearray[i].ToString().EndsWith(".doc")) && !(strfilearray[i].ToString().EndsWith(".docx")))
                if (!(strfilearray[i].ToString().EndsWith(".doc")) && !(strfilearray[i].ToString().EndsWith(".docx")) && !(strfilearray[i].ToString().EndsWith(".pdf")))
                {

                    {
                        List<string> tmp = new List<string>(strfilearray);
                        tmp.RemoveAt(i);
                        strfilearray = tmp.ToArray();
                    }
                }
                else
                {
                    if (strfilearray[i].ToString().Contains("~$"))//to discard the supporting files of the docx
                    {
                        List<string> tmp = new List<string>(strfilearray);
                        tmp.RemoveAt(i);
                        strfilearray = tmp.ToArray();
                    }
                    else
                    {
                        filecount = filecount + 1;
                    }
                }
                i = i - 1;
            }
            //  textBox1.Text = folderBrowserDialog1.SelectedPath.ToString();

            lblFileCnt.Text = filecount.ToString();


            Program.GlobalFileCount = strfilearray;
            
            if(lblFileCnt.Text=="0")
                MessageBox.Show( " No Files of doc or pdf format found. Please choose different folder.");
            else
                MessageBox.Show(lblFileCnt.Text+" File(s) found. ");
        }

        private void funcAddfiles(string[] allfiles)
        {
            try
            {
                for (int i = 0; i < allfiles.Length; i++)
                {
                    string[] strArryFilename = allfiles[i].Split('\\');
                    string strfilename = strArryFilename[strArryFilename.Length - 1];
                    listBox1.Items.Insert(i, strfilename);
                    System.Windows.Forms.Application.DoEvents();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

               
        }
        private void btndone_Click(object sender, EventArgs e)
        {
            // Rule FRM = new Rule();
            //FRM.Show();
            //this.Hide();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(listBox1.SelectedItem.ToString());
        }
    }
}
