﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace minesweep1.mineform
{
    public partial class newform : Form
    {

        datamanager.datamanager dm = new datamanager.datamanager();
        public newform()
        {
            InitializeComponent();
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        
        
        private void newform_Load(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            bindtocombo(cbrul1);

            bindtocombo(cbrul2);

            bindtocombo(cbrul3);

            bindtocombo(cbrul4);

        }
        public void bindtocombo(ComboBox cb)
        {
            string qry = "select distinct Associationcriteria from dbo.tbl_criteria where criteria_ActiveFlag=1";
            DataSet ds = dm.GetDataSet(qry);
            if (ds.Tables[0].Rows.Count > 0)
            {
                cb.DataSource = ds.Tables[0];
                //cb.ValueMember = ds.Tables[0].Columns[0].ToString();
                cb.DisplayMember = ds.Tables[0].Columns[0].ToString();
            }
        }
        public void bindtocomborule(ComboBox cb, string selectedAr)
        {
            string qry = "select distinct criteria from dbo.tbl_criteria where criteria_ActiveFlag=1 and Associationcriteria='" + selectedAr +"'";
            DataSet ds = dm.GetDataSet(qry);
            if (ds.Tables[0].Rows.Count > 0)
            {
                cb.DataSource = ds.Tables[0];
               // cb.ValueMember = ds.Tables[0].Columns[0].ToString();
                cb.DisplayMember = ds.Tables[0].Columns[0].ToString();
            }
        }
        private void cbrul1_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindtocomborule(cbrul5, cbrul1.Text);
        }

        private void cbrul2_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindtocomborule(cbrul6, cbrul2.Text);
        }

        private void btnsetRule_Click(object sender, EventArgs e)
        {
            Program.criteria[0]=cbrul1.Text+"="+ cbrul5.Text;
              Program.criteria[1]=cbrul2.Text+"="+cbrul6.Text;
             Program.criteria[2]=cbrul3.Text+"="+cbrul7.Text;
             Program.criteria[3] = cbrul4.Text + "=" + cbrul8.Text;
             MessageBox.Show("Rules selected successfully");
             
        }

        private void cbrul3_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindtocomborule(cbrul7, cbrul3.Text);
        }

        private void cbrul4_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindtocomborule(cbrul8, cbrul4.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
            button2.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel4.Visible = true;
            button3.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel5.Visible = true;
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
