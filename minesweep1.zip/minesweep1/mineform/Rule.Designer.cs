﻿namespace minesweep1.mineform
{
    partial class Rule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rul = new System.Windows.Forms.Label();
            this.assrul = new System.Windows.Forms.Label();
            this.txtrul = new System.Windows.Forms.TextBox();
            this.txtassrul = new System.Windows.Forms.TextBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnup = new System.Windows.Forms.Button();
            this.btnres = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.slno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.lblcount = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rul
            // 
            this.rul.AutoSize = true;
            this.rul.BackColor = System.Drawing.Color.Transparent;
            this.rul.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rul.ForeColor = System.Drawing.Color.Navy;
            this.rul.Location = new System.Drawing.Point(116, 189);
            this.rul.Name = "rul";
            this.rul.Size = new System.Drawing.Size(156, 25);
            this.rul.TabIndex = 0;
            this.rul.Text = "Rule                          :";
            // 
            // assrul
            // 
            this.assrul.AutoSize = true;
            this.assrul.BackColor = System.Drawing.Color.Transparent;
            this.assrul.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.assrul.ForeColor = System.Drawing.Color.Navy;
            this.assrul.Location = new System.Drawing.Point(116, 261);
            this.assrul.Name = "assrul";
            this.assrul.Size = new System.Drawing.Size(168, 25);
            this.assrul.TabIndex = 1;
            this.assrul.Text = "Association Rule    :";
            // 
            // txtrul
            // 
            this.txtrul.Location = new System.Drawing.Point(312, 192);
            this.txtrul.Name = "txtrul";
            this.txtrul.Size = new System.Drawing.Size(249, 20);
            this.txtrul.TabIndex = 2;
            this.txtrul.TextChanged += new System.EventHandler(this.txtrul_TextChanged);
            // 
            // txtassrul
            // 
            this.txtassrul.Location = new System.Drawing.Point(312, 264);
            this.txtassrul.Name = "txtassrul";
            this.txtassrul.Size = new System.Drawing.Size(249, 20);
            this.txtassrul.TabIndex = 3;
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.Transparent;
            this.btnsave.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btnsave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsave.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.ForeColor = System.Drawing.Color.Transparent;
            this.btnsave.Location = new System.Drawing.Point(312, 342);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(135, 61);
            this.btnsave.TabIndex = 4;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnup
            // 
            this.btnup.BackColor = System.Drawing.Color.Transparent;
            this.btnup.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btnup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnup.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnup.ForeColor = System.Drawing.Color.Transparent;
            this.btnup.Location = new System.Drawing.Point(312, 342);
            this.btnup.Name = "btnup";
            this.btnup.Size = new System.Drawing.Size(135, 61);
            this.btnup.TabIndex = 5;
            this.btnup.Text = "Update";
            this.btnup.UseVisualStyleBackColor = false;
            this.btnup.Click += new System.EventHandler(this.btnup_Click);
            // 
            // btnres
            // 
            this.btnres.BackColor = System.Drawing.Color.Transparent;
            this.btnres.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btnres.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnres.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnres.ForeColor = System.Drawing.Color.Transparent;
            this.btnres.Location = new System.Drawing.Point(489, 342);
            this.btnres.Name = "btnres";
            this.btnres.Size = new System.Drawing.Size(135, 61);
            this.btnres.TabIndex = 6;
            this.btnres.Text = "Reset";
            this.btnres.UseVisualStyleBackColor = false;
            this.btnres.Click += new System.EventHandler(this.btnres_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.slno,
            this.mid,
            this.Column2,
            this.Column3,
            this.Column5,
            this.Column4});
            this.dataGridView1.GridColor = System.Drawing.Color.Navy;
            this.dataGridView1.Location = new System.Drawing.Point(192, 443);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(432, 145);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // slno
            // 
            this.slno.DataPropertyName = "slno";
            this.slno.HeaderText = "SL NO.";
            this.slno.Name = "slno";
            this.slno.ReadOnly = true;
            this.slno.Width = 50;
            // 
            // mid
            // 
            this.mid.DataPropertyName = "criteria_MasterId";
            this.mid.HeaderText = "mid";
            this.mid.Name = "mid";
            this.mid.ReadOnly = true;
            this.mid.Visible = false;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "criteria";
            this.Column2.HeaderText = "Rule";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Associationcriteria";
            this.Column3.HeaderText = "Association rule";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Edit";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column5.Text = "Edit";
            this.Column5.UseColumnTextForButtonValue = true;
            this.Column5.Width = 30;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Delete";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // lblcount
            // 
            this.lblcount.AutoSize = true;
            this.lblcount.BackColor = System.Drawing.Color.Transparent;
            this.lblcount.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcount.ForeColor = System.Drawing.Color.Navy;
            this.lblcount.Location = new System.Drawing.Point(654, 443);
            this.lblcount.Name = "lblcount";
            this.lblcount.Size = new System.Drawing.Size(36, 25);
            this.lblcount.TabIndex = 8;
            this.lblcount.Text = "----";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-2, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1401, 48);
            this.panel1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(41, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 36);
            this.label1.TabIndex = 5;
            this.label1.Text = "Minesweep";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(-1, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(250, 63);
            this.label2.TabIndex = 13;
            this.label2.Text = "Criteria";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Papyrus", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Navy;
            this.label7.Location = new System.Drawing.Point(36, 123);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(612, 51);
            this.label7.TabIndex = 14;
            this.label7.Text = "You have criteria,then you achieve success!";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Rule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = global::minesweep1.Properties.Resources.images__2_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblcount);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnres);
            this.Controls.Add(this.btnup);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.txtassrul);
            this.Controls.Add(this.txtrul);
            this.Controls.Add(this.assrul);
            this.Controls.Add(this.rul);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Rule";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rule";
            this.Load += new System.EventHandler(this.Rule_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label rul;
        private System.Windows.Forms.Label assrul;
        private System.Windows.Forms.TextBox txtrul;
        private System.Windows.Forms.TextBox txtassrul;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnup;
        private System.Windows.Forms.Button btnres;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn slno;
        private System.Windows.Forms.DataGridViewTextBoxColumn mid;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewButtonColumn Column5;
        private System.Windows.Forms.DataGridViewButtonColumn Column4;
        private System.Windows.Forms.Label lblcount;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
    }
}