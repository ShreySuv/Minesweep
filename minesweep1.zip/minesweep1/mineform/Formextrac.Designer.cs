﻿namespace minesweep1.mineform
{
    partial class Formextrac
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Formextrac));
            this.lbl1 = new System.Windows.Forms.Label();
            this.lblcount = new System.Windows.Forms.Label();
            this.lblrule1 = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.listFile = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdb2 = new System.Windows.Forms.RadioButton();
            this.rdb1 = new System.Windows.Forms.RadioButton();
            this.tmrCheck = new System.Windows.Forms.Timer(this.components);
            this.lblfcnt = new System.Windows.Forms.Label();
            this.txtpath = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.savbtn = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblrule4 = new System.Windows.Forms.Label();
            this.lblrule3 = new System.Windows.Forms.Label();
            this.lblrule2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbltimecount = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.BackColor = System.Drawing.Color.Transparent;
            this.lbl1.Font = new System.Drawing.Font("Papyrus", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(911, 111);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(83, 19);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "File Count   :";
            // 
            // lblcount
            // 
            this.lblcount.AutoSize = true;
            this.lblcount.BackColor = System.Drawing.Color.Transparent;
            this.lblcount.Font = new System.Drawing.Font("Papyrus", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcount.Location = new System.Drawing.Point(1005, 111);
            this.lblcount.Name = "lblcount";
            this.lblcount.Size = new System.Drawing.Size(24, 19);
            this.lblcount.TabIndex = 1;
            this.lblcount.Text = "---";
            // 
            // lblrule1
            // 
            this.lblrule1.AutoSize = true;
            this.lblrule1.BackColor = System.Drawing.Color.Transparent;
            this.lblrule1.Font = new System.Drawing.Font("Papyrus", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrule1.ForeColor = System.Drawing.Color.Navy;
            this.lblrule1.Location = new System.Drawing.Point(86, 194);
            this.lblrule1.Name = "lblrule1";
            this.lblrule1.Size = new System.Drawing.Size(50, 19);
            this.lblrule1.TabIndex = 4;
            this.lblrule1.Text = "Rule 1";
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.Transparent;
            this.btn1.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn1.Font = new System.Drawing.Font("Papyrus", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.ForeColor = System.Drawing.Color.Transparent;
            this.btn1.Location = new System.Drawing.Point(46, 320);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(131, 30);
            this.btn1.TabIndex = 6;
            this.btn1.Text = "Extract Now";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // listFile
            // 
            this.listFile.Font = new System.Drawing.Font("Papyrus", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listFile.FormattingEnabled = true;
            this.listFile.ItemHeight = 18;
            this.listFile.Location = new System.Drawing.Point(79, 365);
            this.listFile.Name = "listFile";
            this.listFile.Size = new System.Drawing.Size(671, 112);
            this.listFile.TabIndex = 7;
            this.listFile.SelectedIndexChanged += new System.EventHandler(this.listFile_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.rdb2);
            this.groupBox1.Controls.Add(this.rdb1);
            this.groupBox1.Font = new System.Drawing.Font("Papyrus", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Navy;
            this.groupBox1.Location = new System.Drawing.Point(33, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(232, 47);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select    :";
            // 
            // rdb2
            // 
            this.rdb2.AutoSize = true;
            this.rdb2.Location = new System.Drawing.Point(143, 12);
            this.rdb2.Name = "rdb2";
            this.rdb2.Size = new System.Drawing.Size(61, 22);
            this.rdb2.TabIndex = 1;
            this.rdb2.TabStop = true;
            this.rdb2.Text = "AND";
            this.rdb2.UseVisualStyleBackColor = true;
            // 
            // rdb1
            // 
            this.rdb1.AutoSize = true;
            this.rdb1.Location = new System.Drawing.Point(70, 12);
            this.rdb1.Name = "rdb1";
            this.rdb1.Size = new System.Drawing.Size(49, 22);
            this.rdb1.TabIndex = 0;
            this.rdb1.TabStop = true;
            this.rdb1.Text = "OR";
            this.rdb1.UseVisualStyleBackColor = true;
            // 
            // tmrCheck
            // 
            this.tmrCheck.Tick += new System.EventHandler(this.tmrCheck_Tick);
            // 
            // lblfcnt
            // 
            this.lblfcnt.AutoSize = true;
            this.lblfcnt.BackColor = System.Drawing.Color.Transparent;
            this.lblfcnt.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfcnt.ForeColor = System.Drawing.Color.Navy;
            this.lblfcnt.Location = new System.Drawing.Point(741, 337);
            this.lblfcnt.Name = "lblfcnt";
            this.lblfcnt.Size = new System.Drawing.Size(38, 25);
            this.lblfcnt.TabIndex = 12;
            this.lblfcnt.Text = "- - -";
            // 
            // txtpath
            // 
            this.txtpath.Location = new System.Drawing.Point(169, 496);
            this.txtpath.Name = "txtpath";
            this.txtpath.Size = new System.Drawing.Size(262, 20);
            this.txtpath.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Font = new System.Drawing.Font("Papyrus", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(464, 492);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 29);
            this.button1.TabIndex = 14;
            this.button1.Text = "Browse";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // savbtn
            // 
            this.savbtn.BackColor = System.Drawing.Color.Transparent;
            this.savbtn.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.savbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.savbtn.Font = new System.Drawing.Font("Papyrus", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savbtn.ForeColor = System.Drawing.Color.Transparent;
            this.savbtn.Location = new System.Drawing.Point(397, 527);
            this.savbtn.Name = "savbtn";
            this.savbtn.Size = new System.Drawing.Size(94, 31);
            this.savbtn.TabIndex = 15;
            this.savbtn.Text = "Save";
            this.savbtn.UseVisualStyleBackColor = false;
            this.savbtn.Click += new System.EventHandler(this.savbtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1355, 48);
            this.panel1.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(39, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 36);
            this.label1.TabIndex = 5;
            this.label1.Text = "Minesweep";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(24, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(526, 63);
            this.label2.TabIndex = 6;
            this.label2.Text = "Final Extraction  ";
            // 
            // lblrule4
            // 
            this.lblrule4.AutoSize = true;
            this.lblrule4.BackColor = System.Drawing.Color.Transparent;
            this.lblrule4.Font = new System.Drawing.Font("Papyrus", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrule4.ForeColor = System.Drawing.Color.Navy;
            this.lblrule4.Location = new System.Drawing.Point(85, 298);
            this.lblrule4.Name = "lblrule4";
            this.lblrule4.Size = new System.Drawing.Size(50, 19);
            this.lblrule4.TabIndex = 19;
            this.lblrule4.Text = "Rule 4";
            // 
            // lblrule3
            // 
            this.lblrule3.AutoSize = true;
            this.lblrule3.BackColor = System.Drawing.Color.Transparent;
            this.lblrule3.Font = new System.Drawing.Font("Papyrus", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrule3.ForeColor = System.Drawing.Color.Navy;
            this.lblrule3.Location = new System.Drawing.Point(86, 265);
            this.lblrule3.Name = "lblrule3";
            this.lblrule3.Size = new System.Drawing.Size(50, 19);
            this.lblrule3.TabIndex = 20;
            this.lblrule3.Text = "Rule 3";
            // 
            // lblrule2
            // 
            this.lblrule2.AutoSize = true;
            this.lblrule2.BackColor = System.Drawing.Color.Transparent;
            this.lblrule2.Font = new System.Drawing.Font("Papyrus", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrule2.ForeColor = System.Drawing.Color.Navy;
            this.lblrule2.Location = new System.Drawing.Point(85, 229);
            this.lblrule2.Name = "lblrule2";
            this.lblrule2.Size = new System.Drawing.Size(50, 19);
            this.lblrule2.TabIndex = 21;
            this.lblrule2.Text = "Rule 2";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Location = new System.Drawing.Point(79, 136);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(291, 55);
            this.panel2.TabIndex = 22;
            // 
            // lbltimecount
            // 
            this.lbltimecount.AutoSize = true;
            this.lbltimecount.Location = new System.Drawing.Point(875, 416);
            this.lbltimecount.Name = "lbltimecount";
            this.lbltimecount.Size = new System.Drawing.Size(35, 13);
            this.lbltimecount.TabIndex = 23;
            this.lbltimecount.Text = "label3";
            this.lbltimecount.Visible = false;
            // 
            // Formextrac
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1334, 690);
            this.Controls.Add(this.lbltimecount);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lblrule2);
            this.Controls.Add(this.lblrule3);
            this.Controls.Add(this.lblrule4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.savbtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtpath);
            this.Controls.Add(this.lblfcnt);
            this.Controls.Add(this.listFile);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.lblrule1);
            this.Controls.Add(this.lblcount);
            this.Controls.Add(this.lbl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Formextrac";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Formextrac_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lblcount;
        private System.Windows.Forms.Label lblrule1;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.ListBox listFile;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdb2;
        private System.Windows.Forms.RadioButton rdb1;
        private System.Windows.Forms.Timer tmrCheck;
        private System.Windows.Forms.Label lblfcnt;
        private System.Windows.Forms.TextBox txtpath;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button savbtn;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblrule4;
        private System.Windows.Forms.Label lblrule3;
        private System.Windows.Forms.Label lblrule2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbltimecount;

    }
}