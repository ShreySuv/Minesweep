﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace minesweep1.mineform
{
    public partial class Auserdetail : Form
    {
        datamanager.datamanager dm = new datamanager.datamanager();
        string sex;
        public Auserdetail()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Aadminpage FRM = new Aadminpage();
            FRM.Show();
            this.Hide();

        }
        public bool isvalid()
        {
            if (txtname.Text == "")
            {
                MessageBox.Show("Please enter username");
                txtname.Focus();
                return false;
            }
            if (txtpass.Text == "" || txtpass.Text.Length<6)
            {
                MessageBox.Show("Please enter password(6 character)");
                txtpass.Focus();
                return false;
            }
            if (txtnum.Text == "" || txtnum.Text.Length<10)
            {
                MessageBox.Show("Please enter conatct number(10 digits)");
                txtnum.Focus();
                return false;
            }
            if (txtdesig.Text == "")
            {
                MessageBox.Show("Please enter designation");
                txtdesig.Focus();
                return false;
            }
            if (txtmail.Text == "")
            {
                MessageBox.Show("Please enter mail id");
                txtmail.Focus();
                return false;
            }
            else
            {
                System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

                if (txtmail.Text.Length > 0)
                {
                    if (!rEMail.IsMatch(txtmail.Text))
                    {
                        MessageBox.Show("Enter Correct Email Id", "Pro Plus", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        txtmail.SelectAll();

                        //e.Cancel = true;


                    }
                }

            }
            


            return true;
        }

        private void btndone_Click(object sender, EventArgs e)
        {
            if (isvalid())
            {
                string qry1 ="select * from tbl_logpage where log_username='"+txtname.Text+"'";
                if(!dm.CheckIsRecordExist(qry1))
                {
                string username = txtname.Text;
                string password = txtpass.Text;
                string num = txtnum.Text;
                string designation = txtdesig.Text;
                string email = txtmail.Text;

            
            if (radioButton1.Checked == true)
            {
                 sex = "male";
              //  MessageBox.Show(sex);

            }
            else
            {
                 sex = "female";
              //  MessageBox.Show(sex);
             }
            
            
                string qry = "insert into tbl_logpage (log_username , log_pass,log_contact,log_Sex,log_designation,log_email) values ('" + txtname.Text + "','" + txtpass.Text + "','" + txtnum.Text + "','" + sex + "','" + txtdesig.Text + "','" + txtmail.Text + "')";
                string res = dm.ExecuteQuery(qry);
                if (res != "")
                {
                    MessageBox.Show("SUCCESS");
                }
                else
                {
                    MessageBox.Show("UNSUCCESSFULL");
                }
            }
            else
            {
                MessageBox.Show("user already exists");
            }
                }
        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Auserdetail_Load(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
        }

        private void txtnum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }

        }

        private void txtmail_Validating(object sender, CancelEventArgs e)
        {
            //System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

            //if (txtmail.Text.Length > 0)
            //{
            //    if (!rEMail.IsMatch(txtmail.Text))
            //    {
            //        MessageBox.Show("Enter Correct Email Id", "Pro Plus", MessageBoxButtons.OK, MessageBoxIcon.Error);

            //        txtmail.SelectAll();

            //        e.Cancel = true;


            //    }
            //}

        }

        private void txtmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

                txtpass.Focus();
            }
        }

        private void txtpass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

                txtnum.Focus();
            }
        }

        private void txtdesig_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

                txtmail.Focus();
            }
        }

        private void txtmail_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

                txtname.Focus();
            }
        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtname_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rName = new System.Text.RegularExpressions.Regex(@"^[A-Za-z][a-z]*[a-z]$");

            if (txtname.Text.Length > 0)
            {
                if (!rName.IsMatch(txtname.Text))
                {
                    MessageBox.Show("Enter Correct name!", "Pro Plus", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    txtname.SelectAll();

                    e.Cancel = true;


                }
            }
        }

        private void txtnum_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rNum = new System.Text.RegularExpressions.Regex(@"(^[0-9]){6}");

            if (txtname.Text.Length > 0)
            {
                if (!rNum.IsMatch(txtnum.Text))
                {
                    MessageBox.Show("Enter Correct Number", "Pro Plus", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    txtnum.SelectAll();

                    e.Cancel = true;


                }
            }
        }

       

        private void txtdesig_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rdesig = new System.Text.RegularExpressions.Regex(@"^[a-z ]*[a-z]$");

            if (txtdesig.Text.Length > 0)
            {
                if (!rdesig.IsMatch(txtdesig.Text))
                {
                    MessageBox.Show("Enter Correct designation", "Pro Plus", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    txtdesig.SelectAll();

                    e.Cancel = true;


                }
            }
        }

        private void Auserdetail_Validating(object sender, CancelEventArgs e)
        {

        }

        private void txtpass_Validating(object sender, CancelEventArgs e)
        {

        }

        private void txtnum_Validating_1(object sender, CancelEventArgs e)
        {

        }

      
    }
}
