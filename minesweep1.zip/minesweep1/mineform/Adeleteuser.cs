﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace minesweep1.mineform
{
    public partial class Adeleteuser : Form
    {
        datamanager.datamanager dm = new datamanager.datamanager();
        public Adeleteuser()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Aadminpage FRM = new Aadminpage();
            FRM.Show();
            this.Hide();

        }
        public bool isvalid()
        {
            if (txtname.Text == "")
            {
                MessageBox.Show("Please enter name");
                txtname.Focus();
                return false;
            }
            return true;
        }
        private void txtname_TextChanged(object sender, EventArgs e)
        {
            
        }

       
        private void btnok_Click(object sender, EventArgs e)
        {
            DialogResult result1 = MessageBox.Show("Do you want to delete the user:'" + txtname.Text + "'?", "Important questions", MessageBoxButtons.YesNo);
            if (result1 == DialogResult.Yes)
            {
                if (isvalid())
                {
                    String name = txtname.Text;
                    String qry1 = "select * from tbl_logpage where log_username='"+name+"' and log_Activeflag=1";
                    DataSet ds = dm.GetDataSet(qry1);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        String qry = "delete from tbl_logpage where log_username='" + name + "' and log_Activeflag=1";
                        String res = dm.ExecuteQuery(qry);
                        if (res != "")
                        {
                            MessageBox.Show("SUCCESS");
                        }
                        else
                        {
                            MessageBox.Show("UNSUCCESSFULL");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username does not exist");
                    }
                }
            }
            else
            {
                MessageBox.Show("The user:'" + txtname.Text + "'is not deleted");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
