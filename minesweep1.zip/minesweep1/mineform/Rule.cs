﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace minesweep1.mineform
{
    public partial class Rule : Form
    {
        datamanager.datamanager dm = new datamanager.datamanager();
        string qrry = "select row_number() over(order by criteria_MasterId)as slno,criteria_MasterId,criteria,Associationcriteria from tbl_criteria where criteria_ActiveFlag=1";
        public Rule()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int mid = int.Parse(dataGridView1.CurrentRow.Cells["mid"].Value.ToString());
            Program.mid = mid;
            if (e.ColumnIndex == 0)
            {
                btnsave.Visible = false;
                btnup.Visible = true;
                txtrul.Text = dataGridView1.CurrentRow.Cells["Column2"].Value.ToString();
                txtassrul.Text = dataGridView1.CurrentRow.Cells["Column3"].Value.ToString();
                
            }
            if (e.ColumnIndex == 1)
            {
                DialogResult dr = MessageBox.Show("Are u sure?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    string qry10 = "update tbl_criteria set criteria_ActiveFlag=0 where criteria_MasterId = '" + Program.mid + "'";
                    string res10 = dm.ExecuteQuery(qry10);
                    if (res10 != "")
                    {
                        MessageBox.Show("success");
                        BindGrid(dataGridView1, qrry);
                    }
                    else
                    {
                        MessageBox.Show("nope");
                    }
                }
            }
        }
        public bool isvalid()
        {
            if (txtrul.Text == "")
            {
                MessageBox.Show("Please enter rule");
                txtrul.Focus();
                return false;
            }
            if (txtassrul.Text == "")
            {
                MessageBox.Show("Please enter associated rule");
                txtassrul.Focus();
                return false;
            }
            return true;
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            if (isvalid())
            {
                string qry1 = "select * from tbl_criteria where criteria='" + txtrul.Text + "' and criteria_ActiveFlag=1";
                    if (!dm.CheckIsRecordExist(qry1))
                    {
                string Rule = txtrul.Text;
                string assRule = txtassrul.Text;
                string qry = "insert into tbl_criteria (criteria , associationcriteria) values ('"+Rule+"','"+assRule+"')";
                string res = dm.ExecuteQuery(qry);
                if (res!= "")
                {
                    MessageBox.Show("SUCCESS");
                    clearall();
                    
                    
                    
                     BindGrid(dataGridView1, qrry);
                }
                else 
                {
                    MessageBox.Show("UNSUCCESSFULL");
                }
                    }

                    else
                    {
                        MessageBox.Show("Record Already Exists");
                    }
               
            }
            
        }

        public void BindGrid( DataGridView dv, string qrry)
        {
           // string qrry = "select * from tbl_criteria where criteria='" +Rule+ "' and Associationcriteria='" +assRule+ "' and login_ActiveFlag=1";
             DataSet ds = dm.GetDataSet(qrry);
             if (ds.Tables[0].Rows.Count > 0)
             {

                 dv.DataSource = ds.Tables[0];
                 lblcount.Text = ds.Tables[0].Rows.Count.ToString();

             }
             else
             {
                 dv.DataSource = ds.Tables[0];
                 lblcount.Text = "0";
             }
        }

        private void Rule_Load(object sender, EventArgs e)
        {
            btnsave.Visible = true;
            btnup.Visible = false;
            BindGrid(dataGridView1,qrry);

        }

        private void btnup_Click(object sender, EventArgs e)
        {
           
            if (isvalid())
            {
                string Rule = txtrul.Text;
                string assRule = txtassrul.Text;
                string qry1 = "update tbl_criteria set criteria='" + Rule + "',Associationcriteria='" + assRule + "' where criteria_ActiveFlag=1 and criteria_MasterId='" + Program.mid + "'";
                string res = dm.ExecuteQuery(qry1);
                if (res != "")
                {
                   // string qrrry = "select * from tbl_criteria where criteria_ActiveFlag=1";

                    BindGrid(dataGridView1, qrry);
                    btnsave.Visible = true;
                    btnup.Visible = false;
                    clearall();
                }
                else
                {
                    MessageBox.Show("UNSUCCESSFULL");
                }
            }
        }

        private void btnres_Click(object sender, EventArgs e)
        {
            clearall();
        }
        public void clearall()
        {

            txtrul.Text = "";
            txtassrul.Text = "";
            btnsave.Visible = true;
            btnup.Visible = false;

        }

        private void txtrul_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
       
    }
}
