﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace minesweep1.mineform
{
    public partial class signin : Form
    {
        datamanager.datamanager dm = new datamanager.datamanager();
        public signin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void signin_Load(object sender, EventArgs e)
        {

        }
        public bool isvalid()
        {
            if (txtuser.Text == "")
            {
                MessageBox.Show("Please enter username");
                txtuser.Focus();
                return false;
            }
            if (txtpass.Text == "")
            {
                MessageBox.Show("Please enter password");
                txtpass.Focus();
                return false;
            }
            return true;
        }
         private void btnok_Click(object sender, EventArgs e)
        {
            if (isvalid())
            {
                string username = txtuser.Text;
                string password = txtpass.Text;
                Program.maindes = username;
                String qry1 = "select * from tbl_logpage where log_username='" + username + "' and log_Activeflag=1";
                DataSet ds1 = dm.GetDataSet(qry1);
                string qry = "select * from tbl_logpage where log_username='" + username + "' and log_pass='" + password + "' and log_Activeflag=1";
                DataSet ds = dm.GetDataSet(qry);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string des = ds.Tables[0].Rows[0]["log_designation"].ToString();
                    Program.usermid = int.Parse(ds.Tables[0].Rows[0]["log_MasterId"].ToString());
                    Program.password = ds.Tables[0].Rows[0]["log_pass"].ToString();
                    if (des == "manager")
                    {
                        Aadminpage FRM = new Aadminpage();
                        FRM.Show();
                        this.Hide();
                    }
                    else
                    {
                        MDIHome FRM = new MDIHome();
                        FRM.Show();
                        this.Hide();
                    }
                }
                else
                {
                    if (username == "admin")
                    {
                        MessageBox.Show("Incorrect Password");
                    }
                    else if (ds1.Tables[0].Rows.Count > 0)
                    {
                        MessageBox.Show("Incorrect Password");
                    }
                    else
                    {
                        MessageBox.Show("Username does not exist!");
                    }

                }
            }
        }

        private void txtuser_TextChanged(object sender, EventArgs e)
        {

        }

        private void btncan_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpass_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar == 13)
            {
                btnok_Click(sender, e);
            }


        }

        private void txtuser_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

                txtpass.Focus();
            }
        }
    }
}
