﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace minesweep1.mineform
{
    public partial class Aadminpage : Form
    {
        public Aadminpage()
        {
            InitializeComponent();
        }

        private void Aadminpage_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Aviewuser FRM = new Aviewuser();
            FRM.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Auserdetail FRM = new Auserdetail();
            FRM.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Adeleteuser FRM = new Adeleteuser();
            FRM.Show();
            this.Hide();

        }

        private void btnback_Click(object sender, EventArgs e)
        {
           // Application.Exit();
            signin FRM = new signin();
            FRM.Show();
            this.Hide();

        }

        private void btnchan_Click(object sender, EventArgs e)
        {
            changepass FRM = new changepass();
            FRM.Show();
            this.Hide();
        }
    }
}
