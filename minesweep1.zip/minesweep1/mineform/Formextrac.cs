﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Office.Interop.Word;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.IO;

namespace minesweep1.mineform
{
    public partial class Formextrac : Form
    {
        datamanager.datamanager dm = new datamanager.datamanager();
        bool opt1 = false; bool opt2 = false, opt3 = false, opt4 = false;
        string DocContent;
        public Formextrac()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            tmrCheck.Start();
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();
            System.Windows.Forms.Application.DoEvents();
            try
            {
                bool found1 = false;
                bool found2 = false;
                bool found3 = false;
                bool found4 = false;
                listFile.Items.Clear();

                for (int i = 0; i < Program.GlobalFileCount.Length; i++)
                {
                    if (Program.GlobalFileCount[i].ToString().EndsWith(".docx"))
                    {
                        DocContent = ReadDoc(Program.GlobalFileCount[i].ToString());
                    }
                    else if (Program.GlobalFileCount[i].ToString().EndsWith(".pdf"))
                    {
                        DocContent = getPdfContent(Program.GlobalFileCount[i].ToString());
                    }
                    
                    if (rdb1.Checked == true)
                    {
                        checkrules();
                        if (opt1)
                        {
                            found1 = extract(lblrule1);
                            if (found1)
                                display(i);
                            else if (opt2)
                            {
                                found2 = extract(lblrule2);
                                if (found2)
                                    display(i);
                                else if (opt3)
                                {
                                    found3 = extract(lblrule3);
                                    if (found3)
                                        display(i);
                                    else if (found4)
                                    {
                                        found4 = extract(lblrule4);
                                        if (found4)
                                            display(i);

                                    }
                                }
                            }
                        }


                    }
                    else if (rdb2.Checked == true)
                    {
                        checkrules();



                        if (opt1)
                        {
                            found1 = extract(lblrule1);
                            if (found1 && opt2 == false)
                            {
                                display(i);
                            }
                        }
                        if (opt2 && found1)
                        {
                            found2 = extract(lblrule2);

                            if (found2 && opt3 == false)
                            {
                                listFile.Items.Add(Program.GlobalFileCount[i].ToString());
                                System.Windows.Forms.Application.DoEvents();
                            }

                        }
                        if (opt3 && found2)
                        {
                            found3 = extract(lblrule3);

                            if (found3 && opt4 == false)
                            {
                                listFile.Items.Add(Program.GlobalFileCount[i].ToString());
                                System.Windows.Forms.Application.DoEvents();
                            }

                        }
                        if (opt4 && found3)
                        {
                            found4 = extract(lblrule4);
                            if (found4)
                            {
                                listFile.Items.Add(Program.GlobalFileCount[i].ToString());
                                System.Windows.Forms.Application.DoEvents();
                            }

                        }


                    }
                    found1 = false;
                    found2 = false;
                    found3 = false;
                    found4 = false;
                   
                   
                }
                tmrCheck.Stop();
                sw.Stop();
                string t = sw.ElapsedMilliseconds.ToString();
                MessageBox.Show("Searching over in ['"+t+"']milliseconds  '"+ lblfcnt.Text + " File(s) found. ");
             

            }
            catch (Exception ex)
            {
                ex.Data.Clear();
            }
        }


        public void display(int i)
        {
            listFile.Items.Add(Program.GlobalFileCount[i].ToString());
            System.Windows.Forms.Application.DoEvents();
        }

        public void checkrules()
        {
            if (lblrule1.Text != "--=--")
            {
                opt1 = true;
            }
            if (lblrule2.Text != "--=--")
            {
                opt2 = true;
            }
            if (lblrule3.Text != "--=--")
            {
                opt3 = true;
            }
            if (lblrule4.Text != "--=--")
            {
                opt4 = true;

            }
           
        }

        public bool extract(Label rule)
        {
            string[] criteria1split = rule.Text.Split('=');
            string[] criteria1 = criteria1split[1].ToString().Split('$');
            for (int j = 0; j < criteria1.Length; j++)
            {
                if ((DocContent.ToUpper().Contains(criteria1[j].ToUpper().Trim().ToString()) && (criteria1[j].ToUpper().Trim().ToString() != "")))
                {
                    return true;
                    //break;
                }

            }
            return false;
        }

        private void Formextrac_Load(object sender, EventArgs e)
        {
            lblcount.Text = Program.GlobalFileCount.Length.ToString();
            lblrule1.Text = Program.criteria[0];
            lblrule2.Text = Program.criteria[1];
            lblrule3.Text = Program.criteria[2];
            lblrule4.Text = Program.criteria[3];
            string[] sc1 = Program.criteria[0].Split('=');
            DataSet ds = dm.GetDataSet("select Synonyms from tbl_Synonyms where Standardterm = '" + sc1[1].ToString() + "' and Synonym_ActiveFlag=1");
            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (i == 0)
                    {
                        lblrule1.Text = lblrule1.Text + "$" + ds.Tables[0].Rows[i]["Synonyms"].ToString() + "$";
                    }
                    else
                    {
                        lblrule1.Text = lblrule1.Text + ds.Tables[0].Rows[i]["Synonyms"].ToString() + "$";
                    }

                }
            }
              lblrule1.Text = lblrule1.Text.Trim('$');
            string[] sc2 = Program.criteria[1].Split('=');
            DataSet ds1 = dm.GetDataSet("select Synonyms from tbl_Synonyms where Standardterm = '" + sc2[1].ToString() + "' and Synonym_ActiveFlag=1");
            if (ds1.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
                {
                    if (i == 0)
                    {
                        lblrule2.Text = lblrule2.Text + "$" + ds1.Tables[0].Rows[i]["Synonyms"].ToString() + "$";
                    }
                    else
                    {
                        lblrule2.Text = lblrule2.Text + ds1.Tables[0].Rows[i]["Synonyms"].ToString() + "$";
                    }
                }
            }
            lblrule2.Text = lblrule2.Text.Trim('$');
            string[] sc3 = Program.criteria[2].Split('=');
            DataSet ds2 = dm.GetDataSet("select Synonyms from tbl_Synonyms where Standardterm = '" + sc3[1].ToString() + "' and Synonym_ActiveFlag=1");
            if (ds2.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds2.Tables[0].Rows.Count; i++)
                {
                    if (i == 0)
                    {
                        lblrule3.Text = lblrule3.Text + "$" + ds2.Tables[0].Rows[i]["Synonyms"].ToString() + "$";
                    }
                    else
                    {
                        lblrule3.Text = lblrule3.Text + ds2.Tables[0].Rows[i]["Synonyms"].ToString() + "$";
                    }
                }
            }
            lblrule3.Text = lblrule3.Text.Trim();
            string[] sc4 = Program.criteria[3].Split('=');
            DataSet ds3 = dm.GetDataSet("select Synonyms from tbl_Synonyms where Standardterm = '" + sc4[1].ToString() + "' and Synonym_ActiveFlag=1");
            if (ds3.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds3.Tables[0].Rows.Count; i++)
                {
                    if (i == 0)
                    {
                        lblrule4.Text = lblrule4.Text + "$" + ds3.Tables[0].Rows[i]["Synonyms"].ToString() + "$";
                    }
                    else
                    {
                        lblrule4.Text = lblrule4.Text + ds3.Tables[0].Rows[i]["Synonyms"].ToString() + "$";
                    }
                    
                }
            }
            lblrule4.Text = lblrule4.Text.Trim('$');
        }
        public string getPdfContent(object Filename)
        {
            string temp = "";
            string strText = string.Empty;
            try
            {
                PdfReader reader = new PdfReader((string)Filename);

                for (int page = 1; page <= reader.NumberOfPages; page++)
                {
                    ITextExtractionStrategy its = new iTextSharp.text.pdf.parser.LocationTextExtractionStrategy();
                    String s = PdfTextExtractor.GetTextFromPage(reader, page, its);

                    s = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(s)));
                    strText = strText + s;
                    //strText = strText + Environment.NewLine;

                }
                string[] test = strText.Split('\n');

                for (int i = 0; i < test.Length; i++)
                {
                    temp = temp + test[i] + Environment.NewLine;
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return temp;
        }

        public string ReadDoc(string path)
        {
            Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.Application();
            object file = path;
            object nullobj = System.Reflection.Missing.Value;
            Document doc = wordApp.Documents.Open(ref file, ref nullobj, true, ref nullobj, ref nullobj, ref nullobj, ref nullobj, ref nullobj, ref nullobj, ref nullobj, ref nullobj);
            string result = doc.Content.Text.Trim();
            return result;
        }

        private void tmrCheck_Tick(object sender, EventArgs e)
        {
            lblfcnt.Text = listFile.Items.Count.ToString();
            //int cnt = int.Parse(lbltimecount.Text.ToString());
            //lbltimecount.Text = cnt.ToString();
            System.Windows.Forms.Application.DoEvents();
        }

        private void listFile_SelectedIndexChanged(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(listFile.SelectedItem.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string strfilepath = "";
            
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                strfilepath = fbd.SelectedPath.ToString();
                txtpath.Text = strfilepath;//to select source folder
                Program.screened_files_folder = strfilepath;
            }
           
           

        }

        private void savbtn_Click(object sender, EventArgs e)
        {
            if (txtpath.Text == "")
            {
                MessageBox.Show("Enter File Path");
            }
            else
            {
                for (int i = 0; i < listFile.Items.Count; i++)
                {
                    string[] strArrayFilename = listFile.Items[i].ToString().Split('.');

                    string filename = Path.GetFileName(listFile.Items[i].ToString());

                    string folderpath = Program.screened_files_folder;
                    File.Copy(listFile.Items[i].ToString(), folderpath + "//" + filename);
                }
                MessageBox.Show(" File(s) saved. ");
            }
        }

       

        
        

    }
    
}
