﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace minesweep1
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new mineform.signin());
        }
        public static string[] criteria = new string[4];
        public static string[] GlobalFileCount;
        public static string screened_files_folder;
        public static int mid = 0;
        public static int synmid = 0;
        public static int mdiheight;
        public static int mdiwidth;
        public static int usermid;
        public static string password = "";
        public static int Amdiheight;
        public static int Amdiwidth;
        public static string maindes;
    }
}
