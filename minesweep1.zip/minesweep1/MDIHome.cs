﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace minesweep1
{
    public partial class MDIHome : Form
    {
   

        public MDIHome()
        {
            InitializeComponent();
        }

        private void MDIHome_Load(object sender, EventArgs e)
        {
            Program.mdiheight = pnlheight.Height;
            Program.mdiwidth = pnlwidth.Width;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mineform.synonyms frm = new mineform.synonyms();
            frm.Height = Program.mdiheight;
            frm.Width = Program.mdiwidth;
            frm.MdiParent = this;
            frm.Show();
        }

        private void btnrules_Click(object sender, EventArgs e)
        {
            mineform.Rule frm = new mineform.Rule();
            frm.Height = Program.mdiheight;
            frm.Width = Program.mdiwidth;
            frm.MdiParent = this;
            frm.Show();
            //Application.Exit();
        }

        private void addloc_Click(object sender, EventArgs e)
        {
            mineform.uploaddocument frm = new mineform.uploaddocument();
            frm.Height = Program.mdiheight;
            frm.Width = Program.mdiwidth;
            frm.MdiParent = this;
            frm.Show();
        }

        private void btnrulset_Click(object sender, EventArgs e)
        {
           
                mineform.newform frm = new mineform.newform();
                frm.Height = Program.mdiheight;
                frm.Width = Program.mdiwidth;
                frm.MdiParent = this;
                frm.Show();
            
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            mineform.signin FRM = new mineform.signin();
            FRM.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mineform.Formextrac frm = new mineform.Formextrac();
            frm.Height = Program.mdiheight;
            frm.Width = Program.mdiwidth;
            frm.MdiParent = this;
            frm.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnchangerules_Click(object sender, EventArgs e)
        {
            mineform.changepass frm = new mineform.changepass();
            frm.Height = Program.mdiheight;
            frm.Width = Program.mdiwidth;
            frm.MdiParent = this;
            frm.Show();
        }

       
    }
}
