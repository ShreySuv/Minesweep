﻿namespace minesweep1
{
    partial class MDIHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.pnlheight = new System.Windows.Forms.Panel();
            this.btnextract = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.btnrulset = new System.Windows.Forms.Button();
            this.btnaddloc = new System.Windows.Forms.Button();
            this.btnrules = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pnlwidth = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnchangerules = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.statusStrip.SuspendLayout();
            this.pnlheight.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 707);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1350, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // pnlheight
            // 
            this.pnlheight.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlheight.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlheight.Controls.Add(this.btnextract);
            this.pnlheight.Controls.Add(this.btnexit);
            this.pnlheight.Controls.Add(this.btnrulset);
            this.pnlheight.Controls.Add(this.btnaddloc);
            this.pnlheight.Controls.Add(this.btnrules);
            this.pnlheight.Controls.Add(this.button1);
            this.pnlheight.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlheight.Location = new System.Drawing.Point(0, 100);
            this.pnlheight.Name = "pnlheight";
            this.pnlheight.Size = new System.Drawing.Size(200, 607);
            this.pnlheight.TabIndex = 5;
            // 
            // btnextract
            // 
            this.btnextract.BackColor = System.Drawing.Color.Transparent;
            this.btnextract.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btnextract.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnextract.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnextract.ForeColor = System.Drawing.Color.Transparent;
            this.btnextract.Location = new System.Drawing.Point(49, 396);
            this.btnextract.Name = "btnextract";
            this.btnextract.Size = new System.Drawing.Size(105, 84);
            this.btnextract.TabIndex = 10;
            this.btnextract.Text = "Extract ";
            this.btnextract.UseVisualStyleBackColor = false;
            this.btnextract.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btnexit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnexit.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.ForeColor = System.Drawing.Color.Transparent;
            this.btnexit.Location = new System.Drawing.Point(49, 499);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(105, 86);
            this.btnexit.TabIndex = 9;
            this.btnexit.Text = "Logout";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btnrulset
            // 
            this.btnrulset.BackColor = System.Drawing.Color.Transparent;
            this.btnrulset.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btnrulset.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnrulset.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrulset.ForeColor = System.Drawing.Color.Transparent;
            this.btnrulset.Location = new System.Drawing.Point(49, 294);
            this.btnrulset.Name = "btnrulset";
            this.btnrulset.Size = new System.Drawing.Size(105, 78);
            this.btnrulset.TabIndex = 3;
            this.btnrulset.Text = "Set Rules";
            this.btnrulset.UseVisualStyleBackColor = false;
            this.btnrulset.Click += new System.EventHandler(this.btnrulset_Click);
            // 
            // btnaddloc
            // 
            this.btnaddloc.BackColor = System.Drawing.Color.Transparent;
            this.btnaddloc.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btnaddloc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnaddloc.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddloc.ForeColor = System.Drawing.Color.Transparent;
            this.btnaddloc.Location = new System.Drawing.Point(49, 196);
            this.btnaddloc.Name = "btnaddloc";
            this.btnaddloc.Size = new System.Drawing.Size(105, 76);
            this.btnaddloc.TabIndex = 2;
            this.btnaddloc.Text = "Add Files";
            this.btnaddloc.UseVisualStyleBackColor = false;
            this.btnaddloc.Click += new System.EventHandler(this.addloc_Click);
            // 
            // btnrules
            // 
            this.btnrules.BackColor = System.Drawing.Color.Transparent;
            this.btnrules.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btnrules.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnrules.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrules.ForeColor = System.Drawing.Color.Transparent;
            this.btnrules.Location = new System.Drawing.Point(49, 101);
            this.btnrules.Name = "btnrules";
            this.btnrules.Size = new System.Drawing.Size(105, 73);
            this.btnrules.TabIndex = 1;
            this.btnrules.Text = "Rules";
            this.btnrules.UseVisualStyleBackColor = false;
            this.btnrules.Click += new System.EventHandler(this.btnrules_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(49, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 73);
            this.button1.TabIndex = 0;
            this.button1.Text = "Synonym";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pnlwidth
            // 
            this.pnlwidth.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlwidth.Location = new System.Drawing.Point(200, 100);
            this.pnlwidth.Name = "pnlwidth";
            this.pnlwidth.Size = new System.Drawing.Size(1150, 0);
            this.pnlwidth.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = global::minesweep1.Properties.Resources.images__16_;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.btnchangerules);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1350, 100);
            this.panel1.TabIndex = 4;
            // 
            // btnchangerules
            // 
            this.btnchangerules.BackgroundImage = global::minesweep1.Properties.Resources.images__14_;
            this.btnchangerules.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnchangerules.Font = new System.Drawing.Font("Papyrus", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchangerules.ForeColor = System.Drawing.Color.Transparent;
            this.btnchangerules.Location = new System.Drawing.Point(939, 65);
            this.btnchangerules.Name = "btnchangerules";
            this.btnchangerules.Size = new System.Drawing.Size(135, 29);
            this.btnchangerules.TabIndex = 10;
            this.btnchangerules.Text = "Change pasword";
            this.btnchangerules.UseVisualStyleBackColor = true;
            this.btnchangerules.Click += new System.EventHandler(this.btnchangerules_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Harlow Solid Italic", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(212, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 14);
            this.label5.TabIndex = 9;
            this.label5.Text = "Makes your life easier";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(41, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Minesweep";
            // 
            // MDIHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.pnlwidth);
            this.Controls.Add(this.pnlheight);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip);
            this.IsMdiContainer = true;
            this.Name = "MDIHome";
            this.Text = "MDIHome";
            this.Load += new System.EventHandler(this.MDIHome_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.pnlheight.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlheight;
        private System.Windows.Forms.Button btnrules;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel pnlwidth;
        private System.Windows.Forms.Button btnaddloc;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btnrulset;
        private System.Windows.Forms.Button btnextract;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnchangerules;
    }
}



