﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Data;
using System.Data.SqlClient;
namespace minesweep1.datamanager
{
    class datamanager
    {
        public SqlConnection myConn;
        public String GetConnectionString()
        {
            string strConnectionString = "Data Source=.;initial Catalog=db_test;Integrated Security=false;user id=sa;password=sql123;";
            //Systeem.Configuration.ConfigurationManager.AppSettings["constr"];
            return strConnectionString;
        }
        public bool OpenSQLConnection()
        {
            bool bAttempttoconnect = false;
            try
            {
                if (myConn == null)
                    bAttempttoconnect = true;
                if (bAttempttoconnect == false)
                {
                    if ((myConn.State == ConnectionState.Closed) || (myConn.State == ConnectionState.Broken))
                        bAttempttoconnect = true;
                }
                if (bAttempttoconnect)
                {
                    myConn = new SqlConnection();
                    myConn.ConnectionString = GetConnectionString();
                    myConn.Open();
                }
            }
            catch (Exception ex)
            {
                ex.Data.Clear();
            }
            return bAttempttoconnect;
        }
        public void CloseConnection()
        {
            try
            {
                if (myConn.State == ConnectionState.Open)
                    myConn.Close();
            }
            catch (Exception ex)
            {
                ex.Data.Clear();
            }
        }

        public DataSet GetDataSet(String a_strDataSource)
        {
            System.Data.SqlClient.SqlDataAdapter myAdapter;
            DataSet DS;
            try
            {
                DS = new DataSet();
                myAdapter = new System.Data.SqlClient.SqlDataAdapter(a_strDataSource, GetConnectionString());
                myAdapter.Fill(DS);
                myAdapter.Dispose();
                myAdapter = null;
                return (DS);
            }
            catch (Exception ex)
            {
                ex.Data.Clear();
                return null;
            }
        }
        public bool CheckIsRecordExist(string a_strChkSQLCommand)
        {
            System.Data.SqlClient.SqlCommand objCommand;
            bool RecordExists = false;

            try
            {
                bool AttemptToConnect = OpenSQLConnection();
                objCommand = new System.Data.SqlClient.SqlCommand(a_strChkSQLCommand);
                objCommand.Connection = myConn;
                // objCommand.CommandTimeout = ConnectionTimeOut;
                objCommand.CommandType = CommandType.Text;
                string result = Convert.ToString(objCommand.ExecuteScalar());
                objCommand.Dispose();

                if (result != "")
                {
                    RecordExists = true;
                }

                return RecordExists;
            }
            catch (SqlException ex)
            {
                ex.Data.Clear();
                return RecordExists;
            }
            catch (Exception ex)
            {
                ex.Data.Clear();
                return RecordExists;
            }
            finally
            {
                CloseConnection();
            }
        }
        public string ExecuteQuery(string a_strSQLCommand)
        {
            if (OpenSQLConnection())
            {
                System.Data.SqlClient.SqlCommand objCommand = new System.Data.SqlClient.SqlCommand(a_strSQLCommand);
                try
                {
                    objCommand.Connection = myConn;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.ExecuteNonQuery();
                    objCommand.Dispose();
                    CloseConnection();
                    return "executed successfully";
                }
                catch (Exception ex)
                {
                    return ex.Message.Trim();
                }
            }
            else
            {
                return "connection failed";
            }
        }
    }


}

