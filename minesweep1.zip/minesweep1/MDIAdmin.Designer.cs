﻿namespace minesweep1
{
    partial class MDIAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.btnAddusers = new System.Windows.Forms.Button();
            this.pnlwidthA = new System.Windows.Forms.Panel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.pnlheightA = new System.Windows.Forms.Panel();
            this.btnrules = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusStrip.SuspendLayout();
            this.pnlheightA.SuspendLayout();
            this.panel1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 707);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1350, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // btnAddusers
            // 
            this.btnAddusers.Location = new System.Drawing.Point(49, 40);
            this.btnAddusers.Name = "btnAddusers";
            this.btnAddusers.Size = new System.Drawing.Size(105, 73);
            this.btnAddusers.TabIndex = 0;
            this.btnAddusers.Text = "add users";
            this.btnAddusers.UseVisualStyleBackColor = true;
            this.btnAddusers.Click += new System.EventHandler(this.btnAddusers_Click);
            // 
            // pnlwidthA
            // 
            this.pnlwidthA.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlwidthA.Location = new System.Drawing.Point(200, 100);
            this.pnlwidthA.Name = "pnlwidthA";
            this.pnlwidthA.Size = new System.Drawing.Size(1150, 0);
            this.pnlwidthA.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(509, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel1.Text = "Status";
            // 
            // pnlheightA
            // 
            this.pnlheightA.Controls.Add(this.btnrules);
            this.pnlheightA.Controls.Add(this.btnAddusers);
            this.pnlheightA.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlheightA.Location = new System.Drawing.Point(0, 100);
            this.pnlheightA.Name = "pnlheightA";
            this.pnlheightA.Size = new System.Drawing.Size(200, 585);
            this.pnlheightA.TabIndex = 9;
            // 
            // btnrules
            // 
            this.btnrules.Location = new System.Drawing.Point(49, 157);
            this.btnrules.Name = "btnrules";
            this.btnrules.Size = new System.Drawing.Size(105, 73);
            this.btnrules.TabIndex = 1;
            this.btnrules.Text = "Rules";
            this.btnrules.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1350, 100);
            this.panel1.TabIndex = 8;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 685);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1350, 22);
            this.statusStrip1.TabIndex = 7;
            this.statusStrip1.Text = "StatusStrip";
            // 
            // MDIAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.pnlwidthA);
            this.Controls.Add(this.pnlheightA);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.statusStrip);
            this.IsMdiContainer = true;
            this.Name = "MDIAdmin";
            this.Text = "MDIAdmin";
            this.Load += new System.EventHandler(this.MDIAdmin_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.pnlheightA.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Button btnAddusers;
        private System.Windows.Forms.Panel pnlwidthA;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Panel pnlheightA;
        private System.Windows.Forms.Button btnrules;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
    }
}



